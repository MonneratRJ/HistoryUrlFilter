chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  var domainList = localStorage.getItem("domainList");
  if (domainList) {
    if (changeInfo.status == "complete" && domainList.some(function (domain) {
      return tab.url.includes(domain);
    })) {
      chrome.history.removeVisits(tab.id);
    }
  }
});