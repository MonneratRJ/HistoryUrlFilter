var domainList = [];

if (localStorage.getItem("domainList")) {
    domainList = JSON.parse(localStorage.getItem("domainList"));
}

function addDomain() {
    var domain = document.getElementById("domain-input").value;
    if (domain) {
        domainList.push(domain);
        localStorage.setItem("domainList", JSON.stringify(domainList));
        updateDomainList();
    }
}

function removeDomain() {
    var index = document.getElementById("domain-list").selectedIndex;
    if (index > -1) {
        domainList.splice(index, 1);
        localStorage.setItem("domainList", JSON.stringify(domainList));
        updateDomainList();
    }
}

function updateDomainList() {
    document.getElementById("domain-list").innerHTML = "";
    for (var i = 0; i < domainList.length; i++) {
        var domain = domainList[i];
        var li = document.createElement("li");
        li.textContent = domain;
        document.getElementById("domain-list").appendChild(li);
    }
}

document
    .getElementById("donate-button")
    .addEventListener("click", function () {
        // Your code to open a donate page or send a donation request.
        alert("donation clicked!");
    });

document.getElementById("add-domain").addEventListener("click", addDomain);
document.getElementById("remove-domain").addEventListener("click", removeDomain);

updateDomainList();